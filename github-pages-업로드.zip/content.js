const bank=[
 ['독도가 있는 바다의 이름은 무엇일까요?','동해',['서해','남해','지중해'],'독도는 우리나라 동해에 있어요.'],
 ['독도의 두 큰 섬은 무엇일까요?','동도와 서도',['남도와 북도','제주도와 거제도','백도와 청도'],'독도는 동도와 서도, 주변의 작은 바위섬들로 이루어져 있어요.'],
 ['독도의 행정구역은 어디일까요?','경상북도 울릉군',['제주특별자치도','전라남도 여수시','부산광역시'],'독도의 행정구역은 경상북도 울릉군 울릉읍 독도리예요.'],
 ['독도에서 볼 수 있는 새는 무엇일까요?','괭이갈매기',['타조','펭귄','플라밍고'],'괭이갈매기는 독도에서 번식하는 바닷새예요.'],
 ['독도에 살았던 바다사자의 이름은 무엇일까요?','강치',['반달가슴곰','수달','고라니'],'강치는 과거 독도 주변에 살았던 바다사자예요.'],
 ['독도의 자연을 지키는 행동은 무엇일까요?','쓰레기를 되가져오기',['새의 알 가져가기','식물 꺾기','바다에 플라스틱 버리기'],'독도의 생물과 자연을 보호하고 쓰레기는 되가져와요.'],
 ['대한제국 칙령 제41호가 반포된 해는 언제일까요?','1900년',['1500년','1800년','2000년'],'1900년 대한제국 칙령 제41호는 울도군의 관할 구역을 정했어요.'],
 ['독도 등대가 하는 일은 무엇일까요?','배의 안전한 항해 돕기',['비를 내리게 하기','물고기를 가두기','바닷물을 달게 하기'],'등대는 빛으로 위치를 알려 배의 안전한 항해를 도와요.'],
 ['독도와 가까운 우리나라 섬은 어디일까요?','울릉도',['마라도','거문도','진도'],'독도는 울릉도에서 동남쪽으로 떨어져 있어요.'],
 ['독도를 알아볼 때 좋은 방법은 무엇일까요?','공식 자료와 역사 기록 살피기',['소문만 믿기','사진 제목만 읽기','아무 이야기나 외우기'],'자료의 출처와 역사 기록을 함께 살펴보아요.'],
 ['독도는 어떤 활동으로 만들어진 섬일까요?','화산 활동',['빙하 쌓임','사람의 매립','모래 쌓임'],'독도는 오래전 화산 활동으로 만들어진 화산섬이에요.'],
 ['독도 주변 바다를 보호해야 하는 이유는?','다양한 생물이 살기 때문에',['생물이 전혀 없어서','쓰레기를 버리려고','바다를 없애려고'],'독도와 주변 바다는 다양한 생물이 살아가는 소중한 공간이에요.']
];

bank.push(...[
 [
  "독도에 처음으로 주민등록을 옮긴 주민은 누구일까요?",
  "최종덕",
  [
   "안용복",
   "홍순칠",
   "이사부"
  ],
  "최종덕 씨는 1981년에 독도로 주민등록을 옮겼어요."
 ],
 [
  "독도 주변 동해에서 발견된 ‘불타는 얼음’ 자원은?",
  "가스 하이드레이트",
  [
   "석탄",
   "석유",
   "우라늄"
  ],
  "가스 하이드레이트는 얼음처럼 보이지만 불이 붙어 ‘불타는 얼음’이라고도 불려요."
 ],
 [
  "일본이 자국 영토라고 주장하는 우리나라의 섬은?",
  "독도",
  [
   "거제도",
   "진도",
   "마라도"
  ],
  "독도는 역사적·지리적·국제법적으로 대한민국의 고유 영토예요."
 ],
 [
  "홍순칠 등 33명의 대원들이 독도를 지킨 단체는?",
  "독도의용수비대",
  [
   "별무반",
   "삼별초",
   "독립협회"
  ],
  "1953년에 활동을 시작한 독도의용수비대는 독도를 지켰고, 1956년 경찰에 임무를 넘겼어요."
 ],
 [
  "독도는 어떤 지형일까요?",
  "섬",
  [
   "반도",
   "분지",
   "평야"
  ],
  "독도는 바다로 둘러싸인 섬이에요."
 ],
 [
  "독도는 우리나라의 서쪽에 있다.",
  "X",
  [
   "O"
  ],
  "독도는 우리나라 동쪽, 동해에 있어요.",
  "ox"
 ],
 [
  "독도는 일본의 영토이다.",
  "X",
  [
   "O"
  ],
  "독도는 대한민국의 고유 영토예요.",
  "ox"
 ],
 [
  "독도에는 야생 기린이 살고 있다.",
  "X",
  [
   "O"
  ],
  "기린은 독도의 야생동물이 아니에요. 독도에서는 괭이갈매기 등을 볼 수 있어요.",
  "ox"
 ],
 [
  "독도에는 과거에 강치가 평화롭게 살고 있었다.",
  "O",
  [
   "X"
  ],
  "과거 독도 주변은 강치가 무리 지어 살던 곳이에요.",
  "ox"
 ],
 [
  "지금도 독도에서 살아 있는 독도 강치를 볼 수 있다.",
  "X",
  [
   "O"
  ],
  "독도에 살던 강치는 남획 등으로 사라져 멸종한 것으로 알려져 있어요.",
  "ox"
 ],
 [
  "독도는 사람들이 직접 만든 인공 섬이다.",
  "X",
  [
   "O"
  ],
  "독도는 오래전 화산 활동으로 만들어진 자연 섬이에요.",
  "ox"
 ],
 [
  "독도를 지키기 위해 일본에 건너가 활동한 인물은 태종이다.",
  "X",
  [
   "O"
  ],
  "이 활동으로 알려진 인물은 조선 시대의 안용복이에요.",
  "ox"
 ],
 [
  "독도에는 강치가 살았던 적이 있다.",
  "O",
  [
   "X"
  ],
  "강치는 과거 독도에 살았던 바다사자의 한 종류예요.",
  "ox"
 ],
 [
  "독도 주변 바다에는 문어가 산다.",
  "O",
  [
   "X"
  ],
  "독도 주변 바다는 문어 등 다양한 바다 생물의 서식지예요.",
  "ox"
 ],
 [
  "독도에 사는 식물에는 해국이 있다.",
  "O",
  [
   "X"
  ],
  "해국은 독도의 바위가 많은 해안에서도 자라는 식물이에요.",
  "ox"
 ],
 [
  "일본의 옛 지도는 모두 독도를 일본 영토로 표시했다.",
  "X",
  [
   "O"
  ],
  "옛 지도마다 표현은 달라요. 독도를 일본 영토와 다르게 표시하거나 포함하지 않은 일본 지도도 있어요.",
  "ox"
 ],
 [
  "독도의 날은 10월 25일이다.",
  "O",
  [
   "X"
  ],
  "독도의 날은 대한제국 칙령 제41호와 관련된 10월 25일을 기념해요.",
  "ox"
 ],
 [
  "독도에서 볼 수 있는 바위에는 촛대바위가 있다.",
  "O",
  [
   "X"
  ],
  "독도에는 촛대처럼 생긴 촛대바위를 비롯한 여러 바위가 있어요.",
  "ox"
 ]
]);

const ISLAND_OUTLINE=[[-105,25],[-72,-35],[-25,-90],[8,-75],[38,-110],[75,-55],[110,25],[58,65],[-55,70]];
const ISLANDS=[{x:416,y:281,scale:.48},{x:526,y:299,scale:.39}];
const BOAT_HULL=[[-22,3],[24,3],[13,15],[-13,15]];
function ellipse(x,y,rx,ry,color){ctx.fillStyle=color;ctx.beginPath();ctx.ellipse(x,y,rx,ry,0,0,Math.PI*2);ctx.fill()}
function island(x,y,scale){ctx.save();ctx.translate(x,y);ctx.scale(scale,scale);ellipse(0,30,118,70,'#65b6bd');ctx.fillStyle='#a5a68b';ctx.beginPath();ISLAND_OUTLINE.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath();ctx.fill();ctx.fillStyle='#d0c5a5';ctx.beginPath();ctx.moveTo(-105,25);ctx.lineTo(-72,-35);ctx.lineTo(-25,-90);ctx.lineTo(-17,0);ctx.lineTo(25,40);ctx.lineTo(-55,70);ctx.fill();ellipse(5,18,82,40,'#88aa71');ellipse(-28,12,43,24,'#a4bf7d');if(typeof gameArt!=='undefined'&&gameArt.island){ctx.save();ctx.beginPath();ISLAND_OUTLINE.forEach(([px,py],i)=>i?ctx.lineTo(px,py):ctx.moveTo(px,py));ctx.closePath();ctx.clip();artSprite('island',-108,-111,220,185);ctx.restore();ctx.strokeStyle='#ddfbf9';ctx.lineWidth=9;ctx.beginPath();ISLAND_OUTLINE.forEach(([px,py],i)=>i?ctx.lineTo(px,py):ctx.moveTo(px,py));ctx.closePath();ctx.stroke();ctx.strokeStyle='#5a5844';ctx.lineWidth=2;ctx.stroke()}ctx.restore()}
function lighthouse(x,y,lv){if(typeof paintedTower==='function'&&paintedTower(x,y,lv))return;ctx.save();ctx.translate(x,y);ellipse(0,28,29,10,'#387a7840');ctx.fillStyle='#fcf4df';ctx.beginPath();ctx.moveTo(-16,24);ctx.lineTo(-11,-22);ctx.lineTo(11,-22);ctx.lineTo(16,24);ctx.fill();ctx.fillStyle='#dc8069';ctx.fillRect(-16,-24,32,8);ctx.fillStyle='#fceca5';ctx.fillRect(-10,-37,20,13);ctx.fillStyle='#366674';ctx.beginPath();ctx.moveTo(-16,-38);ctx.lineTo(0,-50);ctx.lineTo(16,-38);ctx.fill();ctx.fillRect(-4,10,8,14);ctx.fillStyle='#366674';ctx.fillRect(16,-62,2,43);ctx.fillStyle='white';ctx.fillRect(18,-62,31,20);ellipse(33,-52,5,5,'#d15d5b');ctx.fillStyle='#356bb0';ctx.beginPath();ctx.arc(33,-51,5,0,Math.PI);ctx.fill();ctx.fillStyle='#263f50';ctx.fillRect(20,-59,5,2);ctx.fillRect(41,-46,5,2);if(lv>=2){ellipse(-15,-45,15,9,'#bd9474');ellipse(-24,-53,8,9,'#cda585');ellipse(-27,-55,1.6,1.6,'#263f50');ctx.strokeStyle='#bd9474';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(-3,-46);ctx.lineTo(6,-52);ctx.stroke()}if(lv===3){ctx.strokeStyle='white';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(-8,-69);ctx.quadraticCurveTo(2,-79,11,-67);ctx.quadraticCurveTo(22,-79,32,-69);ctx.stroke()}ctx.restore()}
